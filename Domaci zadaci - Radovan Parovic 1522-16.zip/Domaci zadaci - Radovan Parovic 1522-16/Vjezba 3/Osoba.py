class Osoba:
    def __init__(self, ime, prezime, datumRodjenja, adresa):
        self._ime = ime
        self._prezime = prezime
        self._datumRodjenja = datumRodjenja
        self._adresa = adresa

    def postaviIme(self, ime):
        self._ime = ime

    def postaviPrezime(self, Prezime):
        self._prezime = prezime

    def postaviDatumRodjenja(self, datum):
        self._datumRodjenja = datum

    def postaviAdresu(self, adresa):
        self._adresa = adresa

    def dajIme(self):
        return self._ime

    def dajPrezime(self):
        return self._prezime

    def dajDatumRodjenja(self):
        return self._datumRodjenja

    def dajAdresu(self):
        return self._adresa

class Djak(Osoba):
    def __init__(self, ime, prezime, datumRodjenja, adresa, OS, odeljenje, godinaUpisa):
        Osoba.__init__(self, ime, prezime, datumRodjenja, adresa)
        self._OS = OS
        self._odeljenje = odeljenje
        self._godinaUpisa = godinaUpisa

    def postaviOS(self, OS):
        self._OS = OS

    def postaviOdeljenje(self, odeljenje):
        self._odeljenje = odeljenje

    def postaviGodinuUpisa(self, godinaUpisa):
        self._godinaUpisa = godinaUpisa

    def dajOS(self):
        return self._OS

    def dajOdeljenje(self):
        return self._odeljenje

    def dajGodinuUpisa(self):
        return self._godinaUpisa

    def razred(self):
        a = str(self.dajOdeljenje())
        a1 = a.split("-")
        return a1[0]

    def obnavljanje(self, p):
        l = self.dajDatumRodjenja()
        l1 = l.split(".")
        godr = int(l1[2])
        u = int(self.dajGodinuUpisa())
        brgod = 2017 - godr
        if p == brgod:
            print "Nije ponavljao"
        else:
            print "Ponavljao je"

    def info(self):
        def info(self):
            print self._ime, self._prezime, self._datumRodjenja, self._adresa, self._OS, self._odeljenje, self._godinaUpisa

class Zaposlen(Osoba):
    def __init__(self, ime, prezime, datumRodjenja, adresa, kompanija, departman, zakljucenjaRO, prekidiRO):
        Osoba.__init__(self, ime, prezime, datumRodjenja, adresa)
        self._kompanija = kompanija
        self._departman = departman
        self._zakljucenjaRO = []
        self._prekidiRO = []

    def postaviKompaniju(self, kompanija):
        self._kompanija = kompanija

    def postaviDepartman(self, departman):
        self._departman = departman

    def postaviZakljucenjaRO(self, zakljucenjaRO):
        self._zakljucenjaRO = zakljucenjaRO

    def postaviPrekideRO(self, prekidiRO):
        self._prekidiRO = prekidiRO

    def dajKompaniju(self):
        return self._kompanija

    def dajDepartman(self):
        return self._departman

    def dajZakljucenjaRO(self):
        return self._zakljucenjaRO

    def dajPrekideRO(self):
        return self._prekidiRO

    def radniStaz(self):
        listaz = self.dajZakljucenjaRO()
        listap = self.dajPrekideRO()
        i = 0
        brd = 0
        while i < len(listap):
            z = listaz[i]
            p = listap[i]
            z1 = z.split(".")
            p1 = p.split(".")
            d1 = int(z1[0])
            m1 = int(z1[1])
            g1 = int(z1[2])
            d2 = int(p1[0])
            m2 = int(p1[1])
            g2 = int(p1[2])
            if d1 <= d2:
                d = d2 - d1
            else:
                d = d2 - d1 + 30
                m2 = m2 - 1
            if m1 <= m2:
                m = m2 - m1
            else:
                m = m2 - m1 + 12
                g2 = g2 - 1
            g = g2 - g1
            brm = m + g * 12
            brd = brd + brm * 30 + d
            i += 1
        return brd

    def info(self):
        print self._ime, self._prezime, self._datumRodjenja, self._adresa, self._kompanija, self._departman, self._zakljucenjaRO, self._prekidiRO

ime = raw_input("Unesite ime djaka: ")
prezime = raw_input("Unesite prezime djaka: ")
dr = raw_input("Unesite datum rodjenja djaka: ")
os = raw_input("Unesite naziv osnovne skole djaka: ")
ad = raw_input("Unesite adresu stanovanja djaka: ")
odeljenje = raw_input("Unesite odeljenje: ")
gu = raw_input("Unesite godinu upisa: ")
d = Djak(ime,prezime,dr,ad,os,odeljenje,gu)
tr = d.razred()
print tr

ime1 = raw_input("Unesite ime zaposlenog: ")
prezime1 = raw_input("Unesite prezime zaposlenog: ")
dr1 = raw_input("Unesite datum rodjenja zaposlenog: ")
ad1 = raw_input("Unesite adresu zaposlenog: ")
kom = raw_input("Unesite kompaniju: ")
dep = raw_input("Unesite departman: ")
listaz = []
listap = []
dz = raw_input("Unesite datum zakljucenja radnog odnosa(d.m.g): ")
dp = raw_input("Unesite datum prekida radnog odnosa(d.m.g): ")
listaz.append(dz)
listap.append(dp)
z = Zaposlen(ime1,prezime1,dr1,ad1,kom,dep,listaz,listap)
