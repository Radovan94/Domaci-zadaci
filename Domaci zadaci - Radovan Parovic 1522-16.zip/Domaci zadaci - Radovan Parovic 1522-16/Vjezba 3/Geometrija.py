import math
class Tacka:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def pomeraj(self, xPomeraj, yPomeraj):
        self.x = self.x + xPomeraj
        self.y = self.y + yPomeraj
        return x,y

    def rastojanje(self, t):
        dx = self.x - t.x
        dy = self.y - t.y
        r = math.sqrt(dx**2 + dy**2)
        return r

class Duz:
    def __init__(self, p=0, k=0):
        self.p = p
        self.k = k

    def kreiraj_duz(self, xp, yp, xk, yk):
        m = Tacka(xp, yp)
        n = Tacka(xk, yk)
        duz = Duz(m,n)
        return duz

    def duzina(self):
        d = self.p.rastojanje(self.k)
        return d

x_poc = input("Unesite x kooridnatu pocetne tacke: ")
y_poc = input("Unesite y kooridnatu pocetne tacke: ")
x_zav = input("Unesite x kooridnatu krajnje tacke: ")
y_zav = input("Unesite y kooridnatu krajnje tacke: ")

t1 = Tacka (x_poc, y_poc)
t2 = Tacka (x_zav, y_zav)
d1 = Duz(t1, t2)
d2 = Duz(t2, t1)
dd = d2.kreiraj_duz(13,42,12,53)
print d1.str()
print d2.str()
