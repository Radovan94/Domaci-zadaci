import math
class Sfera:
    broj = 0
    def __init__(self, xCentar=0, yCentar=0, zCentar=0, poluprecnik =1):
        self.xCentar = xCentar
        self.yCentar = yCentar
        self.zCentar = zCentar
        self.poluprecnik = poluprecnik
        Sfera.broj += 1

    @staticmethod
    def broj_tacaka():
        return (Sfera.broj)

    def zapremina(self):
        r = self.poluprecnik
        zapremina = (4 * (r ** 3) * math.pi) / 3
        return zapremina

print Sfera.broj_tacaka()
sfera = Sfera(0, 0, 0, 4.0)
globus = Sfera(1.0, 1.0, 1.0, 12)
bilijarska_lopta = Sfera(10.0, 10.0, 0.0)
jedinicna_sfera = Sfera(0.0, 0.0, 0.0, 1.0)
print Sfera.broj_tacaka()
print sfera.zapremina()
print globus.zapremina()
print bilijarska_lopta.zapremina()
print jedinicna_sfera.zapremina()