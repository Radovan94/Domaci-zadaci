class Inzenjer:
    def __init__(self, ime, prezime, JMBG, licenca):
        self._ime = ime
        self._prezime = prezime
        self._JMBG = JMBG
        self._licenca = licenca

    def postaviIme(self,ime):
        self._ime = ime

    def postaviPrezime(self,prezime):
        self._prezime = prezime

    def postaviJMBG(self,JMBG):
        self._JMBG = JMBG

    def postaviLicencu(self,licenca):
        self.licenca = licenca

    def dajIme(self):
        return self._ime

    def dajPrezime(self):
        return self._prezime

    def dajJMBG(self):
        return self._JMBG

    def dajLicencu(self):
        return self._licenca

    def info(self):
        print self._ime,self._prezime,self._JMBG,self._licenca

class GeodetskiInzenjer(Inzenjer):
    def __init__(self, ime, prezime, JMBG, licenca, staz):
        Inzenjer.__init__(self, ime, prezime, JMBG, licenca)
        self._staz = staz

    def postaviStaz(self, staz):
        self._staz = staz

    def dajStaz(self):
        return self._staz

    def info(self):
        print self._ime, self._prezime, self._JMBG, self._licenca, self._staz

    def infoLicenca(self):
        l = self.dajLicencu()
        if l == "Nema licencu":
            print "Inzenjer nema licencu"
        else:
            print "Licenca inzenjera je ", a


class ElektrotehnickiInzenjer(Inzenjer):
    def __init__(self, ime, prezime, JMBG, licenca, brojProjekata):
        Inzenjer.__init__(self, ime, prezime, JMBG, licenca)
        self._brojProjekata = brojProjekata

    def postaviBrojProjekata(self, brojProjekata):
        self._brojProjekata = brojProjekata

    def dajBrojProjekata(self):
        return self._brojProjekata

    def info(self):
        print self._ime, self._prezime, self._JMBG, self._licenca, self._brojProjekata

    def infoLicenca(self):
        l = self.dajLicencu()
        if l == "Nema licencu":
            print "Inzenjer nema licencu"
        else:
            print "Licenca inzenjera je ", a

