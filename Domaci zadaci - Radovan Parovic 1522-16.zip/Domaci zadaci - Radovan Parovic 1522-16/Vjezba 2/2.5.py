def karakteri(r):
    n=[]
    for i in range(0,len(r)):
         n.append(r[i])

    return n

recenica = raw_input("Unesite recenicu: ")
print karakteri(recenica)