def suma_elemenata(niz):
    suma = 0
    for i in range(0, len(niz)):
        suma = suma + niz[i]
    return suma

niz1 = input("Unesite elemente niza (odvojite ih zarezom): ")
suma1 = suma_elemenata(niz1)
print suma1