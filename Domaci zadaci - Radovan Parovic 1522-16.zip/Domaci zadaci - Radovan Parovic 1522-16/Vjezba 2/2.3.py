def proizvod_elemenata(niz):
    proizvod = 1
    for i in range(0, len(niz)):
        proizvod = proizvod * niz[i]
    return proizvod

niz1 = input("Unesite elemente niza (odvojite ih zarezom): ")
proizvod1 = proizvod_elemenata(niz1)
print proizvod1