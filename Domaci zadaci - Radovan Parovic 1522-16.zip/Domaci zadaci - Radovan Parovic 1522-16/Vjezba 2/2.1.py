def suma_parnih(niz):
    suma = 0
    for i in range(0, len(niz)):
        if niz[i] % 2 == 0:
            suma = suma + niz[i]
    return suma

niz1 = input("Unesite elemente niza (odvojite ih zarezom): ")
suma1 = suma_parnih(niz1)
print suma1