def kreiranje_niza(niz1,niz2):

  niz = []
  n1 = len(niz1)
  n2 = len(niz2)
  i = 0
  j = 0
  if n1<n2:
      while i<n1:
          niz.insert(j,niz1[i])
          j = j+1
          niz.insert(j,niz2[i])
          i = i+1
          j = j+1
      while i<n2:
          niz.insert(j,niz2[i])
          j = j+1
          i = i+1
  elif n1>n2:
      while i<n2:
          niz.insert(j, niz1[i])
          j = j+1
          niz.insert(j, niz2[i])
          i = i+1
          j = j+1
      while i < n1:
          niz.insert(j, niz1[i])
          j = j+1
          i = i+1
  else:
      while i<n1:
          niz.insert(j, niz1[i])
          j = j+1
          niz.insert(j, niz2[i])
          i = i+1
          j = j+1

  return niz



a = input("Unesite prvi niz: ")
b = input("Unesite drugi niz: ")
redosled = raw_input("Unesite redosled (p ili d): ")
novniz = []
if redosled == "p":
    novniz = kreiranje_niza(a,b)
elif redosled == "d":
    novniz = kreiranje_niza(b,a)
else:
    print "Unijeli ste pogresnu opciju!"

print novniz

