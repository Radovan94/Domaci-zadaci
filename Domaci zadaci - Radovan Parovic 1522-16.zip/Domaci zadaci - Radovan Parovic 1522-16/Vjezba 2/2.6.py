a1=input("Unesi broj tacaka: ")
a=int(a1)
i=0

lista1=[]
lista2=[]
listak=[]

while i<a:
    x=raw_input("Unesite  koordinate (X,Y): ")
    x1=x.split(",")
    lista1.append(float(x1[0]))
    lista2.append(float(x1[1]))
    i+=1
n=int(input("Unesi stepen polinoma: "))
i1=0
while i1<n:
    s=1
    t=1
    a1=1
    j=0
    while j<n:
        if j!=i1:
            s=s*(a1-lista1[j])
            t=t*(lista1[i1]-lista2[j])
        j+=1
    listak.append((s/t)*lista2[i1])
    i1+=1

print "Polinom P(X)=",round(listak[0],2),"*X^",n,
m=n
j1=1
while j1<len(listak):
    if listak[j1]>0:
        print "+",round(listak[j1],2),"*X^",m-1,
    else:
        print round(listak[j1],2), "*X^", m-1,
    j1+=1
    m-=1
print "+",a1