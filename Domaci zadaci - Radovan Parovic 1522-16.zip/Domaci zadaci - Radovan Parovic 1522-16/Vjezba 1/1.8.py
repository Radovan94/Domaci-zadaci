import random
broj = random.randint (0,100)
ime = raw_input("Unesite svoje ime: ")

for i in range(1,50):
    b1 = input("Unesite broj: ")
    if b1 < broj:
        print "Broj je veci"
    elif (b1 > broj):
        print "Broj je manji"
    else:
        print "Pogodili ste broj"
        break
print "Broj pokusaja je: ",i
