a = raw_input ("Unesite prvi cetverocifren broj: ")
b = raw_input ("Unesite drugi cetverocifren broj: ")

a1 = int(a)
b1 = int(b)

suma1 = 0
suma2 = 0
suma3 = 0

if a1 >= 1000 and a1 < 10000:
    if b1 >= 1000 and b1 < 10000:
        for i in b:
            suma1 = suma1 + int(i)
        print "Suma cifara drugog broja je:",suma1

        for j in range(0,4):
            if (j== 0 or j==2):
                suma2 = suma2 + int(a[j])
            else:
                suma3 = suma3 + int(a[j])

        razlika = suma2 - suma3
        print "Razlika cifara prvog broja je:", abs(razlika)


else:
    print "Niste unijeli cetverocifrene brojeve!"

