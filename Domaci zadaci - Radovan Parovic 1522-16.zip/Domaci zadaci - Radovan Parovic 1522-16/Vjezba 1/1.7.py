k1 = raw_input("Unesite koordinate tacke A (x,y): ")
k2 = raw_input("Unesite koordinate tacke B (x,y): ")
k3 = raw_input("Unesite koordinate tacke C (x,y): ")
k4 = raw_input("Unesite koordinate tacke M (x,y): ")
a = k1.split(",")
b = k2.split(",")
c = k3.split(",")
m = k4.split(",")
Pt = ((float(a[0])*(float(b[1])-float(c[1])) + float(b[0])*(float(c[1])-float(a[1])) + float(c[0])*(float(a[1])-float(b[1]))))/2
Pabm = ((float(a[0])*(float(b[1])-float(m[1])) + float(b[0])*(float(m[1])-float(a[1])) + float(m[0])*(float(a[1])-float(b[1]))))/2
Pacm = ((float(a[0])*(float(c[1])-float(m[1])) + float(c[0])*(float(m[1])-float(a[1])) + float(m[0])*(float(a[1])-float(c[1]))))/2
Pbcm = ((float(b[0])*(float(c[1])-float(m[1])) + float(c[0])*(float(m[1])-float(b[1])) + float(m[0])*(float(b[1])-float(c[1]))))/2
P = Pabm + Pacm + Pbcm
if (Pt==P):
    print "DA"
else:
    print "NE"