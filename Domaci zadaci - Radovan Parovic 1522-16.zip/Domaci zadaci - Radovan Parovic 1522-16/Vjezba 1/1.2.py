x = input("Unesi x: ")
y = input("Unesi y: ")
print "Uneseni brojevi su:",x, "i", y
print "Zbir je:", x + y
print "Razlika je: ", x - y
print "Proizvod je:", x * y
print "Ceo broj pri djeljenju je: ", x / y
print "Ostatak pri djeljenju je: ", x % y