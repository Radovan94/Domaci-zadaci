pravac1 = raw_input("Unesite prvi pravac (stepeni:minuti:sekunde): ")
pravac2 = raw_input("Unesite drugi pravac (stepeni:minuti:sekunde): ")
pr_1 = pravac1.split(":")
pr_2 = pravac2.split(":")

s1 = pr_1[0]
m1 = pr_1[1]
sek1 = pr_1[2]
p1 = float(s1) + float(m1)/60 + float(sek1)/3600

s2 = pr_2[0]
m2 = pr_2[1]
sek2 = pr_2[2]
p2 = float(s2) + float(m2)/60 + float(sek2)/3600

if p1 >= p2:
    ugao = p1 - p2
    print round(ugao, 4)
else:
    ugao1 = 360 + (p1-p2)
    print round(ugao1, 4)