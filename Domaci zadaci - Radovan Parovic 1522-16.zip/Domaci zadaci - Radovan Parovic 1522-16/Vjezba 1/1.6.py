k = raw_input("Unesite pet karaktera: ")
br = "0,1,2,3,4,5,6,7,8,9"
broj = 0
if len(k) <= 5:
  for i in k:
    for j in br:
        if i == j:
            broj +=1
  print broj
else:
    print "Niste uneli pet karaktera!"
