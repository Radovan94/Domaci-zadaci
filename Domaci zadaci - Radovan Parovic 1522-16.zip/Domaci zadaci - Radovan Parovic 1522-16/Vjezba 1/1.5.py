broj = raw_input("Unesite petocifren broj: ")
b1 = int(broj)
m = 0

if (b1 >= 10000 and b1 < 100000):
    for i in broj:
        if int(i) > m:
            m = int(i)
    print m
else:
    print "Niste unijeli petocifren broj!"